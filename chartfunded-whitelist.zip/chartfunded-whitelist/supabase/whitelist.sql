-- =====================================================================
-- CHART FUNDED — NFT Whitelist (Supabase SQL Editor me ek baar run karo)
-- Public sirf RPC se submit kar sakta hai. List sirf admin dekh sakta hai.
-- =====================================================================

-- 1. ADMINS (koi policy nahi = sirf SQL Editor se add hote hain)
create table if not exists public.wl_admins (
  user_id    uuid primary key references auth.users(id) on delete cascade,
  created_at timestamptz not null default now()
);
alter table public.wl_admins enable row level security;

create or replace function public.wl_is_admin()
returns boolean language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.wl_admins where user_id = auth.uid());
$$;

-- 2. WHITELIST
create table if not exists public.whitelist (
  id          bigint generated always as identity primary key,
  x_handle    text not null check (x_handle ~ '^[A-Za-z0-9_]{1,15}$'),
  telegram    text not null check (telegram ~ '^[A-Za-z0-9_]{5,32}$'),
  discord     text not null check (discord ~ '^[a-z0-9_.]{2,32}$'),
  wallet      text not null check (wallet ~ '^0x[0-9a-f]{40}$'),
  status      text not null default 'pending' check (status in ('pending','approved','rejected')),
  created_at  timestamptz not null default now()
);
create unique index if not exists whitelist_x_uq      on public.whitelist (lower(x_handle));
create unique index if not exists whitelist_wallet_uq on public.whitelist (wallet);
create index        if not exists whitelist_created   on public.whitelist (created_at desc);

alter table public.whitelist enable row level security;
drop policy if exists "wl admin read" on public.whitelist;
create policy "wl admin read" on public.whitelist
  for select to authenticated using (public.wl_is_admin());
-- insert/update/delete policy jaan-boojh ke nahi — sab RPC se

-- 3. PUBLIC SUBMIT
create or replace function public.whitelist_submit(
  p_x text, p_tg text, p_dc text, p_wallet text)
returns text language plpgsql security definer set search_path = public as $$
declare
  v_x  text := regexp_replace(trim(coalesce(p_x,  '')), '^@', '');
  v_tg text := regexp_replace(trim(coalesce(p_tg, '')), '^@', '');
  v_dc text := lower(trim(coalesce(p_dc, '')));
  v_w  text := lower(trim(coalesce(p_wallet, '')));
begin
  if v_x  !~ '^[A-Za-z0-9_]{1,15}$' then return 'bad_x'; end if;
  if v_tg !~ '^[A-Za-z0-9_]{5,32}$' then return 'bad_tg'; end if;
  if v_dc !~ '^[a-z0-9_.]{2,32}$'   then return 'bad_dc'; end if;
  if v_w  !~ '^0x[0-9a-f]{40}$' or v_w = '0x' || repeat('0', 40) then return 'bad_wallet'; end if;

  -- Bot flood guard: ek minute me max 60 entries
  if (select count(*) from public.whitelist where created_at > now() - interval '1 minute') >= 60 then
    return 'busy';
  end if;

  begin
    insert into public.whitelist (x_handle, telegram, discord, wallet)
    values (v_x, v_tg, v_dc, v_w);
  exception when unique_violation then
    return 'duplicate';
  end;
  return 'ok';
end $$;

-- 4. ADMIN STATUS CHANGE
create or replace function public.whitelist_set_status(p_id bigint, p_status text)
returns void language plpgsql security definer set search_path = public as $$
begin
  if not public.wl_is_admin() then raise exception 'forbidden'; end if;
  if p_status not in ('pending','approved','rejected') then raise exception 'bad status'; end if;
  update public.whitelist set status = p_status where id = p_id;
end $$;

-- 5. PERMISSIONS
revoke all on public.whitelist, public.wl_admins from anon;
revoke execute on function public.whitelist_submit(text, text, text, text) from public;
revoke execute on function public.whitelist_set_status(bigint, text) from public, anon;
revoke execute on function public.wl_is_admin() from public, anon;
grant  execute on function public.whitelist_submit(text, text, text, text) to anon, authenticated;
grant  execute on function public.whitelist_set_status(bigint, text) to authenticated;
grant  execute on function public.wl_is_admin() to authenticated;

-- 6. APNA ADMIN BANAO
-- Supabase > Authentication > Users > "Add user" se apna email/password banao,
-- phir uska User UID yahan daal ke ye line run karo:
-- insert into public.wl_admins (user_id) values ('YOUR-USER-UID');
